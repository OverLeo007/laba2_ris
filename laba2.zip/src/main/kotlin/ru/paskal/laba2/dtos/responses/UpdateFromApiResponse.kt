package ru.paskal.laba2.dtos.responses

data class UpdateFromApiResponse(
    var response: String? = null
)
