package ru.paskal.laba2.exceptions

class BadRequestException(message: String) : RuntimeException(message)