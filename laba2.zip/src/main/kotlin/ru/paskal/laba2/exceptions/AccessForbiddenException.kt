package ru.paskal.laba2.exceptions

class AccessForbiddenException(message: String) : RuntimeException(message)